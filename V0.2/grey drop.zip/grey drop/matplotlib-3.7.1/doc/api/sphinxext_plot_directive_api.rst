=======================================
``matplotlib.sphinxext.plot_directive``
=======================================

.. automodule:: matplotlib.sphinxext.plot_directive
   :no-undoc-members:
