**********************
``matplotlib._enums``
**********************

.. automodule:: matplotlib._enums
   :no-members:

   .. autoclass:: JoinStyle
      :members: demo
      :exclude-members: bevel, miter, round, input_description

   .. autoclass:: CapStyle
      :members: demo
      :exclude-members: butt, round, projecting, input_description
