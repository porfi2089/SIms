API Changes for 3.2.0
=====================

.. contents::
   :local:
   :depth: 1

.. include:: /api/prev_api_changes/api_changes_3.2.0/behavior.rst

.. include:: /api/prev_api_changes/api_changes_3.2.0/deprecations.rst

.. include:: /api/prev_api_changes/api_changes_3.2.0/removals.rst

.. include:: /api/prev_api_changes/api_changes_3.2.0/development.rst
