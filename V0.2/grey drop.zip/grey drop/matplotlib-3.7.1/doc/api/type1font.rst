************************
``matplotlib.type1font``
************************

.. attention::
    This module is considered internal.

    Its use is deprecated and it will be removed in a future version.

.. automodule:: matplotlib._type1font
   :members:
   :undoc-members:
   :show-inheritance:
